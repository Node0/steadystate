

import { IRouteableComponent, route } from 'aurelia';
import './steady-state-app.css';

@route({
    routes: [
        { path: ['', 'steady-state'], component: import('./views/steady-state/steady-state'), name: 'steady-state', title: 'SteadyState' },
        { path: 'import', component: import('./views/import/import'), name: 'import', title: 'Import' },
        { path: 'export', component: import('./views/export/export'), name: 'export', title: 'Export' },
        { path: 'help', component: import('./views/help/help'), name: 'help', title: 'Help' }
    ]
})
export class App {
    // Class code here...
}
