export class Import {
    // Import component logic goes here
  }