export class Help {
    // Help component logic goes here
  }